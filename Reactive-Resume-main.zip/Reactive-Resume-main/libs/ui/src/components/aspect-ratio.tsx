import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";

export const AspectRatio = AspectRatioPrimitive.Root;
